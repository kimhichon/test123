let state = { groups: [], pages: [], contents: [], logs: [] };
let pageFilter = '';
let pageGroupFilter = '';
let pagePage = 1;
const selectedPageIds = new Set();
let selectedPageId = localStorage.getItem('pageops-selected-page') || '';
let workspaceModule = 'home';
const workspaceModules = [
  ['home', 'Trang chủ', '⌂'], ['notifications', 'Thông báo', '♧'], ['ads', 'Trình quản lý quảng cáo', '◉'], ['inbox', 'Hộp thư', '□'],
  ['content', 'Nội dung', '▣'], ['connections', 'Nền tảng kết nối', '↗'], ['customers', 'Trung tâm khách hàng', '◎'], ['planner', 'Công cụ lập kế hoạch', '▦'], ['settings', 'Cài đặt', '⚙']
];
let calendarCursor = new Date();
calendarCursor.setDate(1);

const $ = (selector) => document.querySelector(selector);
const esc = (value = '') => String(value).replace(/[&<>\'"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
const groupName = (id) => state.groups.find((g) => g.id === id)?.name || 'Chưa phân nhóm';
const pageName = (id) => state.pages.find((p) => p.id === id)?.name || 'Page đã xóa';
const statusLabel = (status) => ({ draft: 'Bản nháp', scheduled: 'Đã lên lịch', published: 'Đã đăng', failed: 'Thất bại' }[status] || status);
const statusClass = (status) => status === 'published' ? 'green' : status === 'failed' ? 'red' : status === 'scheduled' ? '' : 'gray';
const typeLabel = (type) => ({ video: 'Video', image: 'Hình ảnh', text: 'Bài viết' }[type] || type);
const lastLog = (contentId) => state.logs.find((log) => log.contentId === contentId);

async function api(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

async function refresh() { state = await api('/api/state'); syncRouteFromUrl(); if (!state.pages.some((page) => page.id === selectedPageId)) selectedPageId = state.pages[0]?.id || ''; renderAll(); applyRoute(); }
function renderAll() { renderDashboard(); renderPages(); renderLibrary(); renderCalendar(); renderLogs(); renderWorkspace(); }

function renderDashboard() {
  const failed = state.contents.filter((c) => c.status === 'failed').length;
  const scheduled = state.contents.filter((c) => c.status === 'scheduled').length;
  $('#dashboard').innerHTML = `<div class="grid">
    <div class="card"><div class="metric-label">TỔNG PAGE</div><div class="metric">${state.pages.length}</div><div class="metric-note">Đã thêm vào hệ thống</div></div>
    <div class="card"><div class="metric-label">NHÓM CHỦ ĐỀ</div><div class="metric">${state.groups.length}</div><div class="metric-note">Phân luồng nội dung</div></div>
    <div class="card"><div class="metric-label">NỘI DUNG</div><div class="metric">${state.contents.length}</div><div class="metric-note">Trong thư viện local</div></div>
    <div class="card"><div class="metric-label">ĐANG CHỜ / LỖI</div><div class="metric">${scheduled} / ${failed}</div><div class="metric-note">Theo lịch và nhật ký đăng</div></div>
  </div><div class="panel"><div class="panel-head"><h2>Page theo chủ đề</h2><button class="secondary" data-action="add-group">+ Thêm nhóm</button></div>
  ${state.groups.length ? `<table class="table"><thead><tr><th>NHÓM</th><th>SỐ PAGE</th><th>NỘI DUNG</th><th></th></tr></thead><tbody>${state.groups.map((group) => `<tr><td><span class="pill" style="border-left:3px solid ${esc(group.color)}">${esc(group.name)}</span></td><td>${state.pages.filter((p) => p.groupId === group.id).length}</td><td>${state.contents.filter((c) => c.groupIds?.includes(group.id)).length} nội dung</td><td><button class="secondary" data-delete-group="${group.id}">Xóa</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Chưa có nhóm Page. Tạo nhóm đầu tiên để phân loại theo chủ đề.</div>'}</div>`;
}

function renderPages() {
  const filtered = state.pages.filter((page) => {
    const matchesText = `${page.name} ${page.pageId}`.toLowerCase().includes(pageFilter.toLowerCase());
    return matchesText && (!pageGroupFilter || page.groupId === pageGroupFilter);
  });
  const pageSize = 50;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  pagePage = Math.min(pagePage, pageCount);
  const visiblePages = filtered.slice((pagePage - 1) * pageSize, pagePage * pageSize);
  const visibleIds = visiblePages.map((page) => page.id);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedPageIds.has(id));
  $('#pages').innerHTML = `<div class="toolbar"><input id="page-search" value="${esc(pageFilter)}" placeholder="Tìm Page theo tên hoặc ID..." /><div class="toolbar-actions"><select data-page-group-filter><option value="">Tất cả chủ đề (${state.pages.length})</option>${state.groups.map((group) => `<option value="${group.id}" ${pageGroupFilter === group.id ? 'selected' : ''}>${esc(group.name)} (${state.pages.filter((page) => page.groupId === group.id).length})</option>`).join('')}</select><button class="secondary" data-action="connect-meta">Kết nối Meta</button><button class="secondary" data-action="import-pages">Import CSV</button><button class="primary" data-action="add-page">+ Thêm Page</button></div></div><div class="panel"><div class="panel-head"><div><h2>Danh sách Page (${state.pages.length})</h2><span class="source">Đang xem ${filtered.length} Page · mỗi trang tối đa ${pageSize}</span></div><div class="toolbar-actions"><button class="secondary" data-page-select-visible>${allVisibleSelected ? 'Bỏ chọn trang này' : 'Chọn trang này'}</button><button class="secondary" data-page-clear-selection>Bỏ chọn hết</button></div></div>${selectedPageIds.size ? `<div class="bulk-bar"><strong>Đã chọn ${selectedPageIds.size} Page</strong><select data-bulk-group><option value="">Chọn chủ đề để gán...</option>${state.groups.map((group) => `<option value="${group.id}">${esc(group.name)}</option>`).join('')}<option value="__none">Bỏ phân nhóm</option></select><button class="primary" data-page-bulk-apply>Gán nhóm hàng loạt</button></div>` : ''}${visiblePages.length ? `<table class="table"><thead><tr><th><input type="checkbox" data-page-select-visible ${allVisibleSelected ? 'checked' : ''} /></th><th>TÊN PAGE</th><th>PAGE ID</th><th>NHÓM</th><th>API</th><th></th></tr></thead><tbody>${visiblePages.map((page) => `<tr><td><input type="checkbox" data-select-page="${page.id}" ${selectedPageIds.has(page.id) ? 'checked' : ''} /></td><td><button class="link-button" data-open-page="${page.id}">${esc(page.name)}</button></td><td>${esc(page.pageId || '—')}</td><td><select data-page-group="${page.id}"><option value="">Chưa phân nhóm</option>${state.groups.map((group) => `<option value="${group.id}" ${page.groupId === group.id ? 'selected' : ''}>${esc(group.name)}</option>`).join('')}</select></td><td>${page.hasToken ? '<span class="pill green">Đã kết nối</span>' : '<span class="pill gray">Chưa có token</span>'}</td><td><button class="secondary" data-open-page="${page.id}">Quản trị</button> <button class="secondary" data-delete-page="${page.id}">Xóa</button></td></tr>`).join('')}</tbody></table><div class="pagination"><span>Trang ${pagePage} / ${pageCount}</span><div class="toolbar-actions"><button class="secondary" data-page-nav="prev" ${pagePage <= 1 ? 'disabled' : ''}>‹ Trước</button><button class="secondary" data-page-nav="next" ${pagePage >= pageCount ? 'disabled' : ''}>Sau ›</button></div></div>` : '<div class="empty">Không tìm thấy Page phù hợp.</div>'}</div>`;
}

function targetSummary(content) { return [...(content.groupIds || []).map(groupName), ...(content.pageIds || []).map(pageName)].join(', ') || 'Chưa chọn Page'; }

function showView(viewId, title) {
  document.querySelectorAll('.nav').forEach((item) => item.classList.toggle('active', item.dataset.view === viewId));
  document.querySelectorAll('.view').forEach((view) => view.classList.toggle('active-view', view.id === viewId));
  if (title) $('#view-title').textContent = title;
}

const globalRoutes = { dashboard: '/', pages: '/pages', library: '/library', calendar: '/calendar', logs: '/logs' };
const globalTitles = { dashboard: 'Tổng quan', pages: 'Quản lý Page', library: 'Thư viện nội dung', calendar: 'Lịch đăng', logs: 'Nhật ký đăng' };
const validWorkspaceModules = new Set(workspaceModules.map(([id]) => id));
const pageMetaCache = new Map();
const pageMetaLoading = new Set();
function routePageKey(page) { return page.pageId || page.id; }
function findPageByRouteKey(key) { return state.pages.find((page) => page.id === key || page.pageId === key); }
function syncRouteFromUrl() {
  const parts = window.location.pathname.split('/').filter(Boolean);
  if (parts[0] !== 'page' || !parts[1]) return false;
  const page = findPageByRouteKey(decodeURIComponent(parts[1]));
  if (!page) return false;
  selectedPageId = page.id;
  workspaceModule = validWorkspaceModules.has(parts[2]) ? parts[2] : 'home';
  localStorage.setItem('pageops-selected-page', selectedPageId);
  return true;
}
function applyRoute() {
  if (syncRouteFromUrl()) { renderWorkspace(); showView('page-workspace', `${workspaceModules.find(([id]) => id === workspaceModule)?.[1] || 'Trang chủ'} · ${state.pages.find((page) => page.id === selectedPageId)?.name || ''}`); return; }
  const view = Object.entries(globalRoutes).find(([, route]) => route === window.location.pathname)?.[0] || 'dashboard';
  showView(view, globalTitles[view]);
}
function navigateToWorkspace(pageId, module = 'home') {
  const page = state.pages.find((item) => item.id === pageId); if (!page) return;
  selectedPageId = page.id; workspaceModule = validWorkspaceModules.has(module) ? module : 'home'; localStorage.setItem('pageops-selected-page', selectedPageId);
  history.pushState({}, '', `/page/${encodeURIComponent(routePageKey(page))}/${workspaceModule}`);
  renderWorkspace(); showView('page-workspace', `${workspaceModules.find(([id]) => id === workspaceModule)?.[1] || 'Trang chủ'} · ${page.name}`);
}
function navigateToGlobal(view) { history.pushState({}, '', globalRoutes[view] || '/'); renderWorkspaceSidebar(); showView(view, globalTitles[view]); }

function renderWorkspaceSidebar() {
  const select = $('#workspace-page-select');
  if (!select) return;
  const routeParts = window.location.pathname.split('/').filter(Boolean);
  if (routeParts[0] !== 'page') { $('#workspace-nav').innerHTML = ''; select.innerHTML = `<option value="">Chọn một Page...</option>${state.pages.map((page) => `<option value="${page.id}">${esc(page.name)}</option>`).join('')}`; select.value = selectedPageId; return; }
  select.innerHTML = `<option value="">Chọn một Page...</option>${state.pages.map((page) => `<option value="${page.id}">${esc(page.name)}</option>`).join('')}`;
  select.value = selectedPageId;
  $('#workspace-nav').innerHTML = '';
}

async function loadPageMeta(page, resources) {
  const cache = pageMetaCache.get(page.id) || {};
  const pending = resources.filter((resource) => !cache[resource] && !pageMetaLoading.has(`${page.id}:${resource}`));
  if (!pending.length) return;
  pending.forEach((resource) => pageMetaLoading.add(`${page.id}:${resource}`));
  await Promise.all(pending.map(async (resource) => {
    try { const result = await api(`/api/page/${encodeURIComponent(page.pageId || page.id)}/meta/${resource}`); cache[resource] = { ok: true, payload: result.payload }; }
    catch (error) { cache[resource] = { ok: false, error: error.message }; }
    finally { pageMetaLoading.delete(`${page.id}:${resource}`); }
  }));
  pageMetaCache.set(page.id, cache);
  if (state.pages.some((item) => item.id === page.id) && selectedPageId === page.id) renderWorkspace();
}

function metaPermissionText(page, task) { return page.tasks?.includes(task) ? 'Đã cấp quyền' : 'Chưa cấp quyền'; }
function metaMetric(payload, name) { return payload?.data?.find((item) => item.name === name)?.values?.at(-1)?.value ?? '—'; }

function pageContentFor(page) {
  return state.contents.filter((content) => content.pageIds?.includes(page.id) || content.groupIds?.includes(page.groupId));
}

function workspaceStat(page, contents) {
  const pageResults = state.logs.flatMap((log) => log.results || []).filter((result) => result.pageId === page.id);
  return { total: contents.length, scheduled: contents.filter((content) => content.status === 'scheduled').length, published: pageResults.filter((result) => result.status === 'published').length, failed: pageResults.filter((result) => result.status === 'failed').length };
}

function renderWorkspace() {
  renderWorkspaceSidebar();
  const page = state.pages.find((item) => item.id === selectedPageId);
  if (!page) { $('#page-workspace').innerHTML = '<div class="empty workspace-empty-main">Chọn một Page để mở trang quản trị riêng.</div>'; return; }
  const contents = pageContentFor(page); const stats = workspaceStat(page, contents); const moduleLabel = workspaceModules.find(([id]) => id === workspaceModule)?.[1] || 'Trang chủ'; const remote = pageMetaCache.get(page.id) || {}; const profile = remote.profile?.payload || {}; const displayName = profile.name || page.name; const followers = profile.followers_count ?? profile.fan_count ?? '—';
  const pageMenu = workspaceModules.map(([id, label, icon]) => `<button class="meta-menu-item ${workspaceModule === id ? 'active' : ''}" data-workspace-module="${id}"><span class="meta-menu-icon">${icon}</span>${esc(label)}</button>`).join('');
  let body = '';
  if (workspaceModule === 'home') {
    const recent = contents.slice(0, 5);
    body = `<div class="meta-cover"><div class="meta-cover-glow"></div><div class="meta-cover-page"><div class="meta-avatar">${esc(displayName.slice(0, 1).toUpperCase())}</div><div><h2>${esc(displayName)}</h2><div class="source">Facebook Page · ${esc(page.pageId || 'Chưa có Page ID')}</div></div></div><div class="meta-cover-label">Trang quản trị Page</div></div><div class="meta-profile-row"><div><strong>${esc(displayName)}</strong><div class="source">${remote.profile?.ok ? (profile.about || 'Đã đồng bộ thông tin từ Meta') : (page.hasToken ? 'Đang tải dữ liệu Meta...' : 'Chưa kết nối Meta API')}</div></div><div class="meta-followers"><span>Người theo dõi</span><strong>${esc(followers)}</strong></div></div><div class="meta-actions"><button class="meta-action-primary" data-action="add-content" data-page-id="${page.id}">▣ &nbsp;Tạo bài viết</button><button class="meta-action-button" data-workspace-module="ads">◉ &nbsp;Tạo quảng cáo</button><button class="meta-action-button" data-workspace-module="content">▣ &nbsp;Tạo thước phim</button><button class="meta-action-button" data-workspace-module="content">⊕ &nbsp;Tạo tin</button><button class="meta-action-button" data-workspace-module="content">Xem thêm⌄</button></div><div class="meta-section-heading"><h2>Danh sách việc cần làm</h2><p>Kiểm tra nội dung, lịch đăng và các hoạt động của Page.</p></div><div class="meta-task-card">${stats.failed ? `<strong>Có ${stats.failed} lượt đăng lỗi cần xử lý</strong><div class="source">Mở Nội dung hoặc Nhật ký để xem lỗi và thử lại.</div>` : '<strong>Bạn đã hết việc cần làm.</strong><div class="source">Page đang hoạt động bình thường.</div>'}</div><div class="meta-section-heading"><h2>Phát triển đối tượng</h2><p>Theo dõi hoạt động và nội dung đang chạy trên Page.</p></div><div class="meta-panel-grid"><div class="meta-white-card"><div class="meta-card-icon">◌</div><div><h3>Quản lý nội dung đều đặn</h3><p>Page đang có ${stats.total} nội dung trong thư viện và ${stats.scheduled} lịch đăng chờ xử lý.</p><button class="meta-outline-button" data-workspace-module="planner">Mở công cụ lập kế hoạch</button></div></div><div class="meta-white-card"><div class="meta-card-icon purple">▣</div><div><h3>Quản lý nội dung marketing</h3><p>Xem các bài viết, video và lịch đăng gần đây của Page.</p><button class="meta-outline-button" data-workspace-module="content">Xem tất cả nội dung</button></div></div></div>`;
  } else if (workspaceModule === 'content') {
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Nội dung</h2><p>Quản lý bài viết, hình ảnh và video của ${esc(page.name)}.</p></div><button class="meta-action-primary" data-action="add-content" data-page-id="${page.id}">+ Tạo bài viết</button></div>${contents.length ? `<table class="table"><thead><tr><th>NỘI DUNG</th><th>LOẠI</th><th>LỊCH ĐĂNG</th><th>TRẠNG THÁI</th><th></th></tr></thead><tbody>${contents.map((content) => `<tr><td><strong>${esc(content.title)}</strong></td><td>${typeLabel(content.mediaType)}</td><td>${content.scheduledAt ? new Date(content.scheduledAt).toLocaleString('vi-VN') : '—'}</td><td><span class="pill ${statusClass(content.status)}">${statusLabel(content.status)}</span></td><td><button class="secondary" data-publish="${content.id}">${content.status === 'failed' ? 'Thử lại' : 'Đăng ngay'}</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Page này chưa có nội dung.</div>'}</div>`;
  } else if (workspaceModule === 'planner') {
    const scheduled = contents.filter((content) => content.scheduledAt).sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Công cụ lập kế hoạch</h2><p>Lịch đăng nội dung riêng của ${esc(page.name)}.</p></div><button class="meta-action-primary" data-action="add-content" data-page-id="${page.id}">+ Tạo lịch</button></div>${scheduled.length ? `<table class="table"><thead><tr><th>THỜI GIAN</th><th>NỘI DUNG</th><th>TRẠNG THÁI</th></tr></thead><tbody>${scheduled.map((content) => `<tr><td>${new Date(content.scheduledAt).toLocaleString('vi-VN')}</td><td>${esc(content.title)}</td><td><span class="pill ${statusClass(content.status)}">${statusLabel(content.status)}</span></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Page này chưa có lịch đăng.</div>'}</div>`;
  } else if (workspaceModule === 'notifications') {
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Thông báo</h2><p>Các thông báo và kết quả đăng bài của ${esc(page.name)}.</p></div></div>${state.logs.flatMap((log) => (log.results || []).filter((result) => result.pageId === page.id).map((result) => `<div class="notice"><span class="pill ${result.status === 'published' ? 'green' : 'red'}">${result.status === 'published' ? 'Thành công' : 'Thất bại'}</span><div><strong>${esc(result.pageName)}</strong><div class="source">${esc(result.message || '')}</div></div></div>`)).join('') || '<div class="empty">Chưa có thông báo.</div>'}</div>`;
  } else if (workspaceModule === 'settings') {
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Cài đặt Page</h2><p>Thông tin kết nối và cấu hình riêng của Page.</p></div></div><div class="settings-grid"><div><div class="metric-label">TÊN PAGE</div><strong>${esc(page.name)}</strong></div><div><div class="metric-label">PAGE ID</div><strong>${esc(page.pageId || 'Chưa có')}</strong></div><div><div class="metric-label">NHÓM CHỦ ĐỀ</div><strong>${esc(groupName(page.groupId))}</strong></div><div><div class="metric-label">META API</div><strong>${page.hasToken ? 'Đã kết nối' : 'Chưa kết nối'}</strong></div></div></div>`;
  } else if (workspaceModule === 'ads') {
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Trình quản lý quảng cáo</h2><p>Quảng cáo gắn với Page ${esc(page.name)}.</p></div><button class="meta-action-primary" ${page.tasks?.includes('ADVERTISE') ? '' : 'disabled'}>+ Tạo quảng cáo</button></div><div class="permission-card"><span class="permission-icon">◉</span><div><strong>${metaPermissionText(page, 'ADVERTISE')}</strong><p>${page.tasks?.includes('ADVERTISE') ? 'Page đã có nhiệm vụ quảng cáo. Có thể nối tiếp với tài khoản quảng cáo trong bước cấu hình.' : 'Meta chưa cấp nhiệm vụ ADVERTISE cho Page token này. Hãy kết nối lại OAuth sau khi bật quyền phù hợp.'}</p></div></div></div>`;
  } else if (workspaceModule === 'inbox') {
    const conversations = remote.conversations?.payload?.data || [];
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Hộp thư</h2><p>Tin nhắn của Page ${esc(page.name)}.</p></div></div>${remote.conversations?.ok && conversations.length ? `<table class="table"><thead><tr><th>ĐỐI TƯỢNG</th><th>CẬP NHẬT</th><th>NỘI DUNG GẦN NHẤT</th></tr></thead><tbody>${conversations.map((item) => `<tr><td>${esc(item.participants?.data?.map((person) => person.name).join(', ') || 'Người dùng')}</td><td>${item.updated_time ? new Date(item.updated_time).toLocaleString('vi-VN') : '—'}</td><td>${esc(item.snippet || '')}</td></tr>`).join('')}</tbody></table>` : `<div class="permission-card"><span class="permission-icon">□</span><div><strong>${metaPermissionText(page, 'MESSAGING')}</strong><p>${remote.conversations?.error ? esc(remote.conversations.error) : 'Cần quyền pages_messaging và Page task MESSAGING để đọc hộp thư.'}</p></div></div>`}</div>`;
  } else if (workspaceModule === 'connections') {
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Nền tảng kết nối</h2><p>Quyền và nền tảng đang kết nối với ${esc(page.name)}.</p></div></div><div class="permission-list"><div><span>Meta Graph API</span><strong class="status-ok">${page.hasToken ? 'Đã kết nối' : 'Chưa kết nối'}</strong></div><div><span>Đọc dữ liệu Page</span><strong>${metaPermissionText(page, 'ANALYZE')}</strong></div><div><span>Quản lý nội dung</span><strong>${metaPermissionText(page, 'CREATE_CONTENT')}</strong></div><div><span>Hộp thư</span><strong>${metaPermissionText(page, 'MESSAGING')}</strong></div><div><span>Quảng cáo</span><strong>${metaPermissionText(page, 'ADVERTISE')}</strong></div></div></div>`;
  } else if (workspaceModule === 'customers') {
    body = `<div class="meta-panel"><div class="meta-panel-title"><div><h2>Trung tâm khách hàng</h2><p>Quản lý dữ liệu khách hàng và khách hàng tiềm năng của Page.</p></div></div><div class="permission-card"><span class="permission-icon">◎</span><div><strong>${metaPermissionText(page, 'MANAGE_LEADS')}</strong><p>${page.tasks?.includes('MANAGE_LEADS') ? 'Page đã có quyền quản lý khách hàng tiềm năng.' : 'Cần Page task MANAGE_LEADS và quyền Meta tương ứng để đọc dữ liệu khách hàng.'}</p></div></div></div>`;
  } else {
    body = `<div class="meta-panel module-placeholder"><h2>${esc(moduleLabel)}</h2><p>Khu chức năng riêng của Page <strong>${esc(page.name)}</strong>.</p><p class="source">Giao diện đã tách theo Page. Muốn lấy dữ liệu thật cho mục này cần bật quyền Meta API tương ứng.</p><button class="meta-outline-button" data-workspace-module="home">Về Trang chủ</button></div>`;
  }
  $('#page-workspace').innerHTML = `<div class="meta-page-layout"><aside class="meta-page-sidebar"><div class="meta-page-brand"><div class="meta-mini-avatar">${esc(displayName.slice(0, 1).toUpperCase())}</div><div><strong>${esc(displayName)}</strong><span>Facebook Page</span></div></div><div class="meta-sidebar-divider"></div>${pageMenu}<div class="meta-sidebar-spacer"></div><button class="meta-menu-item ${workspaceModule === 'settings' ? 'active' : ''}" data-workspace-module="settings"><span class="meta-menu-icon">⚙</span>Cài đặt</button><div class="meta-local-status"><span class="dot"></span> PageOps đang chạy local</div></aside><main class="meta-page-main"><div class="meta-page-titlebar"><div><div class="eyebrow">KHU QUẢN TRỊ PAGE</div><h1>${esc(moduleLabel)}</h1></div><button class="meta-task-button">▣ Việc cần làm</button></div><div class="meta-profile-tabs"><span>Trang quản lý tài sản doanh nghiệp</span><span class="active">Tổng quan về Page</span></div>${body}</main></div>`;
  const resources = workspaceModule === 'home' ? ['profile', 'insights'] : workspaceModule === 'inbox' ? ['conversations'] : [];
  if (resources.length && page.hasToken) loadPageMeta(page, resources);
}

function renderWorkspaceLegacy() {
  renderWorkspaceSidebar();
  const page = state.pages.find((item) => item.id === selectedPageId);
  if (!page) { $('#page-workspace').innerHTML = '<div class="empty workspace-empty-main">Chọn một Page trong cột trái hoặc bấm Quản trị ở danh sách Page.</div>'; return; }
  const contents = pageContentFor(page); const stats = workspaceStat(page, contents); const moduleLabel = workspaceModules.find(([id]) => id === workspaceModule)?.[1] || 'Trang chủ';
  let body = '';
  if (workspaceModule === 'home') body = `<div class="grid workspace-stats"><div class="card"><div class="metric-label">NỘI DUNG CỦA PAGE</div><div class="metric">${stats.total}</div></div><div class="card"><div class="metric-label">ĐÃ LÊN LỊCH</div><div class="metric">${stats.scheduled}</div></div><div class="card"><div class="metric-label">ĐÃ ĐĂNG</div><div class="metric">${stats.published}</div></div><div class="card"><div class="metric-label">BÀI LỖI</div><div class="metric">${stats.failed}</div></div></div><div class="panel"><div class="panel-head"><h2>Hoạt động gần đây</h2><button class="primary" data-action="add-content" data-page-id="${page.id}">+ Tạo bài viết</button></div>${contents.length ? `<table class="table"><thead><tr><th>NỘI DUNG</th><th>LOẠI</th><th>TRẠNG THÁI</th></tr></thead><tbody>${contents.slice(0, 8).map((content) => `<tr><td>${esc(content.title)}</td><td>${typeLabel(content.mediaType)}</td><td><span class="pill ${statusClass(content.status)}">${statusLabel(content.status)}</span></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Page này chưa có nội dung.</div>'}</div>`;
  else if (workspaceModule === 'content') body = `<div class="panel"><div class="panel-head"><h2>Nội dung của ${esc(page.name)}</h2><button class="primary" data-action="add-content" data-page-id="${page.id}">+ Tạo nội dung</button></div>${contents.length ? `<table class="table"><thead><tr><th>NỘI DUNG</th><th>LOẠI</th><th>LỊCH ĐĂNG</th><th>TRẠNG THÁI</th><th></th></tr></thead><tbody>${contents.map((content) => `<tr><td>${esc(content.title)}</td><td>${typeLabel(content.mediaType)}</td><td>${content.scheduledAt ? new Date(content.scheduledAt).toLocaleString('vi-VN') : '—'}</td><td><span class="pill ${statusClass(content.status)}">${statusLabel(content.status)}</span></td><td><button class="secondary" data-publish="${content.id}">${content.status === 'failed' ? 'Thử lại' : 'Đăng ngay'}</button></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Chưa có nội dung cho Page này.</div>'}</div>`;
  else if (workspaceModule === 'planner') body = `<div class="panel"><div class="panel-head"><h2>Lịch đăng của ${esc(page.name)}</h2><button class="primary" data-action="add-content" data-page-id="${page.id}">+ Tạo lịch</button></div>${contents.filter((content) => content.scheduledAt).length ? `<table class="table"><thead><tr><th>THỜI GIAN</th><th>NỘI DUNG</th><th>TRẠNG THÁI</th></tr></thead><tbody>${contents.filter((content) => content.scheduledAt).sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt)).map((content) => `<tr><td>${new Date(content.scheduledAt).toLocaleString('vi-VN')}</td><td>${esc(content.title)}</td><td><span class="pill ${statusClass(content.status)}">${statusLabel(content.status)}</span></td></tr>`).join('')}</tbody></table>` : '<div class="empty">Page này chưa có lịch đăng.</div>'}</div>`;
  else if (workspaceModule === 'notifications') body = `<div class="panel"><div class="panel-head"><h2>Thông báo của ${esc(page.name)}</h2></div>${state.logs.flatMap((log) => (log.results || []).filter((result) => result.pageId === page.id).map((result) => `<div class="notice"><span class="pill ${result.status === 'published' ? 'green' : 'red'}">${result.status === 'published' ? 'Thành công' : 'Thất bại'}</span><div><strong>${esc(result.pageName)}</strong><div class="source">${esc(result.message || '')}</div></div></div>`)).join('') || '<div class="empty">Chưa có thông báo.</div>'}</div>`;
  else if (workspaceModule === 'settings') body = `<div class="panel"><div class="panel-head"><h2>Cài đặt Page</h2></div><div class="settings-grid"><div><div class="metric-label">TÊN PAGE</div><strong>${esc(page.name)}</strong></div><div><div class="metric-label">PAGE ID</div><strong>${esc(page.pageId || 'Chưa có')}</strong></div><div><div class="metric-label">NHÓM CHỦ ĐỀ</div><strong>${esc(groupName(page.groupId))}</strong></div><div><div class="metric-label">KẾT NỐI API</div><strong>${page.hasToken ? 'Đã kết nối' : 'Chưa kết nối'}</strong></div></div></div>`;
  else body = `<div class="panel module-placeholder"><h2>${esc(moduleLabel)}</h2><p>Tính năng này đã có khu riêng theo Page. Phần kết nối API tương ứng sẽ được bật ở bước tiếp theo.</p><div class="source">Page đang chọn: ${esc(page.name)} · Page ID: ${esc(page.pageId || '—')}</div></div>`;
  $('#page-workspace').innerHTML = `<div class="page-hero"><div class="page-avatar">${esc(page.name.slice(0, 1).toUpperCase())}</div><div><div class="eyebrow">KHU QUẢN TRỊ PAGE</div><h2>${esc(page.name)}</h2><div class="source">${esc(page.pageId || 'Chưa có Page ID')} · ${page.hasToken ? 'API đã kết nối' : 'Chưa có API token'}</div></div><button class="primary" data-action="add-content" data-page-id="${page.id}">+ Tạo bài viết</button></div><div class="workspace-breadcrumb">${esc(moduleLabel)}</div>${body}`;
}

function renderLibrary() {
  $('#library').innerHTML = `<div class="toolbar"><input placeholder="Tìm nội dung..." /><button class="primary" data-action="add-content">+ Tạo nội dung</button></div><div class="panel"><div class="panel-head"><h2>Kho nội dung local</h2><span class="source">File được lưu trong thư mục media/</span></div>${state.contents.length ? `<table class="table"><thead><tr><th>NỘI DUNG</th><th>LOẠI</th><th>ĐÍCH ĐĂNG</th><th>TRẠNG THÁI</th><th></th></tr></thead><tbody>${state.contents.map((content) => { const log = lastLog(content.id); const error = log?.results?.find((result) => result.status === 'failed')?.message; return `<tr><td><strong>${esc(content.title)}</strong><div class="source">${esc(content.mediaName || 'Không có file')}</div>${error ? `<div class="error-text">${esc(error)}</div>` : ''}</td><td>${typeLabel(content.mediaType)}</td><td>${esc(targetSummary(content))}</td><td><span class="pill ${statusClass(content.status)}">${statusLabel(content.status)}</span></td><td class="row-actions"><button class="secondary" data-publish="${content.id}">${content.status === 'failed' ? 'Thử lại' : 'Đăng ngay'}</button><button class="secondary danger" data-delete-content="${content.id}">Xóa</button></td></tr>`; }).join('')}</tbody></table>` : '<div class="empty">Chưa có nội dung. Tạo nội dung và chọn nhóm hoặc Page để bắt đầu.</div>'}</div>`;
}

function dateKey(date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`; }
function renderCalendar() {
  const year = calendarCursor.getFullYear(); const month = calendarCursor.getMonth(); const startOffset = (new Date(year, month, 1).getDay() + 6) % 7; const cells = [];
  for (let index = 0; index < 42; index += 1) { const date = new Date(year, month, index - startOffset + 1); const events = state.contents.filter((content) => content.scheduledAt?.slice(0, 10) === dateKey(date)); cells.push(`<div class="calendar-day ${date.getMonth() === month ? '' : 'muted-day'}"><div class="day-number">${date.getDate()}</div>${events.map((event) => `<div class="calendar-event ${statusClass(event.status)}" title="${esc(targetSummary(event))}">${esc(event.title)}</div>`).join('')}</div>`); }
  $('#calendar').innerHTML = `<div class="panel calendar-panel"><div class="panel-head"><div><h2>Lịch đăng</h2><div class="calendar-month">${new Intl.DateTimeFormat('vi-VN', { month: 'long', year: 'numeric' }).format(calendarCursor)}</div></div><div class="toolbar-actions"><button class="secondary" data-calendar-nav="prev">‹</button><button class="secondary" data-calendar-nav="today">Hôm nay</button><button class="secondary" data-calendar-nav="next">›</button><button class="primary" data-action="add-content">+ Tạo lịch</button></div></div><div class="calendar-weekdays">${['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map((day) => `<div>${day}</div>`).join('')}</div><div class="calendar-grid">${cells.join('')}</div></div>`;
}

function renderLogs() {
  $('#logs').innerHTML = `<div class="panel"><div class="panel-head"><h2>Nhật ký đăng bài</h2><span class="source">Chi tiết theo từng Page</span></div>${state.logs.length ? state.logs.map((log) => `<div class="log-block"><div class="log-head"><strong>${esc(state.contents.find((content) => content.id === log.contentId)?.title || 'Nội dung đã xóa')}</strong><span class="source">${new Date(log.createdAt).toLocaleString('vi-VN')}</span></div>${(log.results || []).length ? `<table class="table"><tbody>${log.results.map((result) => `<tr><td>${esc(result.pageName)}</td><td><span class="pill ${result.status === 'published' ? 'green' : result.status === 'failed' ? 'red' : 'gray'}">${result.status === 'published' ? 'Thành công' : result.status === 'failed' ? 'Thất bại' : 'Bỏ qua'}</span></td><td class="source">${esc(result.message || '')}</td></tr>`).join('')}</tbody></table>` : '<div class="source">Không có Page đích.</div>'}</div>`).join('') : '<div class="empty">Chưa có lượt đăng nào.</div>'}</div>`;
}

function openModal(title, html) { $('#modal-title').textContent = title; $('#modal-body').innerHTML = html; $('#modal').classList.remove('hidden'); }
function closeModal() { $('#modal').classList.add('hidden'); }

function addGroup() { openModal('Tạo nhóm Page', `<form class="form" id="group-form"><label>Tên nhóm<input name="name" required placeholder="Ví dụ: Tin bóng đá" /></label><label>Màu nhận diện<input name="color" type="color" value="#7c5cff" /></label><div class="actions"><button type="button" class="secondary" id="cancel">Hủy</button><button class="primary">Tạo nhóm</button></div></form>`); $('#group-form').onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.target); try { await api('/api/groups', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: form.get('name'), color: form.get('color') }) }); closeModal(); await refresh(); } catch (error) { alert(error.message); } }; $('#cancel').onclick = closeModal; }

function addPage() { openModal('Thêm Page', `<form class="form" id="page-form"><label>Tên Page<input name="name" required placeholder="Tên hiển thị" /></label><div class="row"><label>Page ID<input name="pageId" placeholder="ID từ Meta Business" /></label><label>Nhóm<select name="groupId"><option value="">Chưa phân nhóm</option>${state.groups.map((group) => `<option value="${group.id}">${esc(group.name)}</option>`).join('')}</select></label></div><label>Page Access Token<input name="token" type="password" placeholder="Để trống nếu chỉ quản lý nội dung" /></label><div class="actions"><button type="button" class="secondary" id="cancel">Hủy</button><button class="primary">Lưu Page</button></div></form>`); $('#page-form').onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.target); try { await api('/api/pages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.fromEntries(form)) }); closeModal(); await refresh(); } catch (error) { alert(error.message); } }; $('#cancel').onclick = closeModal; }

function importPages() { openModal('Import Page bằng CSV', `<p class="source">Định dạng: <code>name,pageId,groupId,token</code>. Dòng đầu là tiêu đề.</p><form class="form" id="csv-form"><label>Chọn file CSV<input name="file" type="file" accept=".csv,text/csv" required /></label><div class="actions"><button type="button" class="secondary" id="cancel">Hủy</button><button class="primary">Import</button></div></form>`); $('#csv-form').onsubmit = async (event) => { event.preventDefault(); const file = event.target.file.files[0]; const lines = (await file.text()).split(/\r?\n/).filter(Boolean); const start = /^name\s*,/i.test(lines[0]) ? 1 : 0; const pages = lines.slice(start).map((line) => { const [name, pageId, groupId, token] = line.split(',').map((value) => value.trim()); return { name, pageId, groupId, token }; }).filter((page) => page.name); try { await api('/api/pages/import', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pages }) }); closeModal(); await refresh(); } catch (error) { alert(error.message); } }; $('#cancel').onclick = closeModal; }

async function addContent(preselectedPageId = '') {
  const groupOptions = state.groups.length ? state.groups.map((group) => `<label class="check"><input type="checkbox" name="groups" value="${group.id}" />${esc(group.name)} (${state.pages.filter((page) => page.groupId === group.id).length} Page)</label>`).join('') : '<span class="source">Chưa có nhóm Page</span>';
  const pageOptions = state.pages.length ? state.pages.map((page) => `<label class="check"><input type="checkbox" name="pages" value="${page.id}" ${(preselectedPageId === page.id || (!preselectedPageId && selectedPageId === page.id)) ? 'checked' : ''} />${esc(page.name)}${page.groupId ? ` <span class="source">(${esc(groupName(page.groupId))})</span>` : ''}</label>`).join('') : '<span class="source">Chưa có Page</span>';
  openModal('Tạo nội dung', `<form class="form" id="content-form"><label>Tiêu đề<input name="title" required placeholder="Ví dụ: Bản tin sáng" /></label><label>Caption<textarea name="caption" placeholder="Nội dung bài đăng, hashtag..."></textarea></label><div class="row"><label>Loại<select name="mediaType"><option value="video">Video</option><option value="image">Hình ảnh</option><option value="text">Bài viết</option></select></label><label>Giờ đăng<input name="scheduledTime" type="time" value="09:00" /></label></div><label>Ngày đăng<input name="scheduledDate" type="date" /></label><label>File media<input name="file" type="file" accept="video/*" /></label><label>Chọn cả nhóm Page</label><div class="checklist">${groupOptions}</div><label>Hoặc chọn Page lẻ</label><div class="checklist">${pageOptions}</div><div class="actions"><button type="button" class="secondary" id="cancel">Hủy</button><button class="primary">Lưu nội dung</button></div></form>`);
  const dateInput = $('#content-form input[type="date"]'); dateInput?.addEventListener('focus', () => dateInput.showPicker?.());
  const typeInput = $('#content-form select[name="mediaType"]'); const fileInput = $('#content-form input[name="file"]');
  const syncFileType = () => { fileInput.accept = typeInput.value === 'video' ? 'video/*' : typeInput.value === 'image' ? 'image/*' : ''; fileInput.disabled = typeInput.value === 'text'; }; typeInput.addEventListener('change', syncFileType); syncFileType();
  $('#content-form').onsubmit = async (event) => {
    event.preventDefault(); const form = new FormData(event.target); const mediaType = form.get('mediaType'); const file = form.get('file');
    const groupIds = [...event.target.querySelectorAll('input[name="groups"]:checked')].map((input) => input.value); const pageIds = [...event.target.querySelectorAll('input[name="pages"]:checked')].map((input) => input.value);
    if (!groupIds.length && !pageIds.length) { alert('Hãy chọn ít nhất một nhóm hoặc một Page.'); return; }
    if ((mediaType === 'video' || mediaType === 'image') && (!file || !file.size)) { alert('Hãy chọn file media trước khi lưu.'); return; }
    if (mediaType === 'video' && file.size && !file.type.startsWith('video/')) { alert('Loại đang là Video nhưng file không phải video.'); return; }
    if (mediaType === 'image' && file.size && !file.type.startsWith('image/')) { alert('Loại đang là Hình ảnh nhưng file không phải ảnh.'); return; }
    try { let mediaName = ''; if (file?.size) { const uploadForm = new FormData(); uploadForm.append('file', file, file.name); const uploaded = await api('/api/media', { method: 'POST', headers: { 'X-Media-Type': mediaType }, body: uploadForm }); mediaName = uploaded.name; } const scheduledDate = form.get('scheduledDate'); const scheduledAt = scheduledDate ? `${scheduledDate}T${form.get('scheduledTime') || '09:00'}` : ''; await api('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: form.get('title'), caption: form.get('caption'), mediaType, scheduledAt, groupIds, pageIds, mediaName }) }); closeModal(); await refresh(); } catch (error) { alert(error.message); }
  }; $('#cancel').onclick = closeModal;
}

document.addEventListener('click', async (event) => {
  const nav = event.target.closest('.nav'); if (nav) { navigateToGlobal(nav.dataset.view); return; }
  const workspaceNav = event.target.closest('[data-workspace-module]'); if (workspaceNav) { navigateToWorkspace(selectedPageId, workspaceNav.dataset.workspaceModule); return; }
  const openPage = event.target.closest('[data-open-page]'); if (openPage) { navigateToWorkspace(openPage.dataset.openPage, 'home'); return; }
  const action = event.target.closest('[data-action]'); if (action) { const name = action.dataset.action; if (name === 'add-group') addGroup(); if (name === 'add-page') addPage(); if (name === 'import-pages') importPages(); if (name === 'add-content') addContent(action.dataset.pageId || ''); if (name === 'connect-meta') window.location.href = '/auth/meta'; return; }
  const calendarNav = event.target.closest('[data-calendar-nav]')?.dataset.calendarNav; if (calendarNav) { if (calendarNav === 'prev') calendarCursor.setMonth(calendarCursor.getMonth() - 1); if (calendarNav === 'next') calendarCursor.setMonth(calendarCursor.getMonth() + 1); if (calendarNav === 'today') { calendarCursor = new Date(); calendarCursor.setDate(1); } renderCalendar(); return; }
  if (event.target.closest('[data-page-select-visible]')) { const filtered = state.pages.filter((page) => `${page.name} ${page.pageId}`.toLowerCase().includes(pageFilter.toLowerCase()) && (!pageGroupFilter || page.groupId === pageGroupFilter)); const visibleIds = filtered.slice((pagePage - 1) * 50, pagePage * 50).map((page) => page.id); const allSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedPageIds.has(id)); visibleIds.forEach((id) => allSelected ? selectedPageIds.delete(id) : selectedPageIds.add(id)); renderPages(); return; }
  if (event.target.closest('[data-page-clear-selection]')) { selectedPageIds.clear(); renderPages(); return; }
  if (event.target.closest('[data-page-bulk-apply]')) { const groupId = $('[data-bulk-group]')?.value; if (!groupId) { alert('Hãy chọn chủ đề cần gán.'); return; } const targetGroupId = groupId === '__none' ? '' : groupId; try { await api('/api/pages/bulk-group', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pageIds: [...selectedPageIds], groupId: targetGroupId }) }); selectedPageIds.clear(); await refresh(); } catch (error) { alert(error.message); } return; }
  if (event.target.closest('[data-page-nav]')) { const nav = event.target.closest('[data-page-nav]').dataset.pageNav; if (nav === 'prev' && pagePage > 1) pagePage -= 1; if (nav === 'next') pagePage += 1; renderPages(); return; }
  if (event.target.dataset.selectPage) { if (selectedPageIds.has(event.target.dataset.selectPage)) selectedPageIds.delete(event.target.dataset.selectPage); else selectedPageIds.add(event.target.dataset.selectPage); renderPages(); return; }
  if (event.target.dataset.deletePage && confirm('Xóa Page này khỏi ứng dụng local?')) { await api(`/api/pages/${event.target.dataset.deletePage}`, { method: 'DELETE' }); await refresh(); }
  if (event.target.dataset.deleteGroup && confirm('Xóa nhóm này? Page sẽ về Chưa phân nhóm.')) { await api(`/api/groups/${event.target.dataset.deleteGroup}`, { method: 'DELETE' }); await refresh(); }
  if (event.target.dataset.deleteContent && confirm('Xóa nội dung và file media local này?')) { await api(`/api/content/${event.target.dataset.deleteContent}`, { method: 'DELETE' }); await refresh(); }
  if (event.target.dataset.publish && confirm('Đăng nội dung này lên các Page đã chọn?')) { try { await api(`/api/publish/${event.target.dataset.publish}`, { method: 'POST' }); await refresh(); alert('Đã chạy đăng. Xem chi tiết trong Nhật ký.'); } catch (error) { alert(error.message); } }
});

document.addEventListener('input', (event) => { if (event.target.id === 'page-search') { pageFilter = event.target.value; pagePage = 1; renderPages(); const input = $('#page-search'); input?.focus(); input?.setSelectionRange(pageFilter.length, pageFilter.length); } });
document.addEventListener('change', async (event) => { if (event.target.dataset.pageGroupFilter !== undefined) { pageGroupFilter = event.target.value; pagePage = 1; renderPages(); return; } if (event.target.dataset.pageGroup) { await api(`/api/pages/${event.target.dataset.pageGroup}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ groupId: event.target.value }) }); await refresh(); } });
$('#workspace-page-select').onchange = (event) => { if (event.target.value) navigateToWorkspace(event.target.value, 'home'); else { localStorage.removeItem('pageops-selected-page'); navigateToGlobal('pages'); } };
window.addEventListener('popstate', () => { renderWorkspace(); applyRoute(); });
$('#quick-add').onclick = addContent; $('#close-modal').onclick = closeModal; refresh();
