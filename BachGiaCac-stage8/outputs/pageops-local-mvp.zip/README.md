# PageOps Local

Ứng dụng MVP chạy cục bộ để quản lý nhiều Facebook Page theo nhóm chủ đề, lưu media trên máy và tạo hàng đợi đăng.

## Chạy

```powershell
node server.mjs
```

Mở `http://127.0.0.1:4173`.

## Dữ liệu local

- `data/state.json`: nhóm Page, Page ID, token, nội dung và log.
- `media/`: video/hình ảnh đã import.

## Kết nối Meta OAuth

1. Tạo Meta App trong [Meta for Developers](https://developers.facebook.com/).
2. Thêm sản phẩm Facebook Login/Facebook Login for Business.
3. Đặt OAuth redirect URI chính xác là `http://localhost:4173/auth/meta/callback`.
4. Chạy app với App ID và App Secret:

```powershell
$env:META_APP_ID='YOUR_META_APP_ID'
$env:META_APP_SECRET='YOUR_META_APP_SECRET'
$env:META_REDIRECT_URI='http://localhost:4173/auth/meta/callback'
$env:META_GRAPH_VERSION='v26.0'
node server.mjs
```

Trong phần Facebook Login Settings, khi chỉ chạy trên máy cá nhân, tắt **Enforce HTTPS** nếu Meta đang bật mục này. Bật **Client OAuth Login** và **Web OAuth Login**, rồi lưu lại. Sau đó mở app bằng `http://localhost:4173`, vào **Quản lý Page** → **Kết nối Meta**. App sẽ lấy toàn bộ Page mà tài khoản Meta được phép quản lý, tự lưu Page ID và Page Access Token local, đồng thời giữ lại nhóm cũ nếu Page đã tồn tại.

OAuth đang xin các quyền `pages_show_list`, `pages_read_engagement`, `pages_manage_posts`. Meta có thể yêu cầu App Review trước khi cho tài khoản ngoài vai trò phát triển/test sử dụng đầy đủ.

Bản MVP đăng text/video/image qua các endpoint Page tương ứng. Hãy kiểm tra quyền API và phiên bản Graph API hiện hành trước khi chạy thực tế.

## CSV import

```csv
name,pageId,groupId,token
Page Bóng đá,123456789,group_xxx,EAAB...
Page Giải trí,987654321,group_yyy,EAAB...
```

Token hiện được lưu local để chạy nội bộ. Khi dùng nghiêm túc nên mã hóa file dữ liệu và không chia sẻ thư mục ứng dụng.
