import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, 'public');
const dataDir = path.join(root, 'data');
const mediaDir = path.join(root, 'media');
const stateFile = path.join(dataDir, 'state.json');
const port = Number(process.env.PORT || 4173);
const graphVersion = process.env.META_GRAPH_VERSION || 'v26.0';
const metaAppId = process.env.META_APP_ID || '';
const metaAppSecret = process.env.META_APP_SECRET || '';
const metaRedirectUri = process.env.META_REDIRECT_URI || `http://localhost:${port}/auth/meta/callback`;
const metaOAuthScopes = process.env.META_OAUTH_SCOPES || 'pages_show_list,pages_read_engagement,pages_manage_posts,read_insights,pages_manage_metadata';
const oauthStates = new Map();

await fsp.mkdir(dataDir, { recursive: true });
await fsp.mkdir(mediaDir, { recursive: true });

const emptyState = { groups: [], pages: [], contents: [], logs: [] };
let state = await readState();

async function readState() {
  try { return JSON.parse(await fsp.readFile(stateFile, 'utf8')); }
  catch { return structuredClone(emptyState); }
}

async function saveState() {
  const tmp = `${stateFile}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(state, null, 2), 'utf8');
  await fsp.rename(tmp, stateFile);
}

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'Content-Type': `${type}; charset=utf-8`, 'Cache-Control': 'no-store' });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}

async function body(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function jsonBody(req) {
  const raw = await body(req);
  return raw.length ? JSON.parse(raw.toString('utf8')) : {};
}

function id(prefix) { return `${prefix}_${crypto.randomUUID()}`; }
function safeName(name) { return String(name || 'upload.bin').replace(/[^a-zA-Z0-9._-]/g, '_'); }
function pageForPublish(page) { return page.token && page.pageId; }
function publicState() {
  return { ...state, pages: state.pages.map(({ token, ...page }) => ({ ...page, hasToken: Boolean(token) })) };
}

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.error) throw new Error(payload.error?.message || `Meta API HTTP ${response.status}`);
  return payload;
}

async function fetchAllPages(firstUrl) {
  const pages = [];
  let next = firstUrl;
  while (next) {
    const payload = await fetchJson(next);
    pages.push(...(payload.data || []));
    next = payload.paging?.next || '';
  }
  return pages;
}

async function pageMetaApi(req, res, url) {
  const match = url.pathname.match(/^\/api\/page\/([^/]+)\/meta\/([^/]+)$/);
  if (req.method !== 'GET' || !match) return false;
  const page = state.pages.find((item) => item.id === decodeURIComponent(match[1]) || item.pageId === decodeURIComponent(match[1]));
  if (!page || !page.pageId || !page.token) return send(res, 404, { error: 'Page chưa có Page ID hoặc Page Access Token' });
  const resource = match[2];
  const base = `https://graph.facebook.com/${graphVersion}/${page.pageId}`;
  try {
    let payload;
    if (resource === 'profile') payload = await fetchJson(`${base}?fields=id,name,about,link,fan_count,followers_count,picture,cover&access_token=${encodeURIComponent(page.token)}`);
    else if (resource === 'posts') payload = await fetchJson(`${base}/feed?fields=id,message,created_time,permalink_url,full_picture&limit=25&access_token=${encodeURIComponent(page.token)}`);
    else if (resource === 'insights') payload = await fetchJson(`${base}/insights?metric=page_post_engagements,page_daily_follows,page_views_total&period=day&access_token=${encodeURIComponent(page.token)}`);
    else if (resource === 'comments') payload = await fetchJson(`${base}/feed?fields=id,message,created_time,comments.limit(25){message,created_time}&limit=25&access_token=${encodeURIComponent(page.token)}`);
    else if (resource === 'conversations') payload = await fetchJson(`${base}/conversations?fields=id,updated_time,snippet,participants&limit=25&access_token=${encodeURIComponent(page.token)}`);
    else return send(res, 400, { error: 'Tài nguyên Meta chưa được hỗ trợ' });
    return send(res, 200, { resource, pageId: page.pageId, payload });
  } catch (error) { return send(res, 502, { error: error.message, resource }); }
}

function oauthError(res, message) {
  return res.writeHead(302, { Location: `/?oauth=error&message=${encodeURIComponent(message)}` }).end();
}

async function metaAuth(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/auth/meta') {
    if (!metaAppId || !metaAppSecret) return oauthError(res, 'Thiếu META_APP_ID hoặc META_APP_SECRET');
    const oauthState = crypto.randomBytes(24).toString('hex');
    oauthStates.set(oauthState, Date.now() + 10 * 60 * 1000);
    const params = new URLSearchParams({ client_id: metaAppId, redirect_uri: metaRedirectUri, state: oauthState, response_type: 'code', scope: metaOAuthScopes });
    res.writeHead(302, { Location: `https://www.facebook.com/${graphVersion}/dialog/oauth?${params}` });
    return res.end();
  }
  if (req.method === 'GET' && url.pathname === '/auth/meta/callback') {
    const returnedState = url.searchParams.get('state') || '';
    const expiresAt = oauthStates.get(returnedState);
    oauthStates.delete(returnedState);
    if (!expiresAt || expiresAt < Date.now()) return oauthError(res, 'OAuth state không hợp lệ hoặc đã hết hạn');
    const code = url.searchParams.get('code');
    if (!code) return oauthError(res, url.searchParams.get('error_description') || 'Meta không trả về authorization code');
    try {
      const tokenParams = new URLSearchParams({ client_id: metaAppId, client_secret: metaAppSecret, redirect_uri: metaRedirectUri, code });
      const userToken = (await fetchJson(`https://graph.facebook.com/${graphVersion}/oauth/access_token?${tokenParams}`)).access_token;
      const pageUrl = `https://graph.facebook.com/${graphVersion}/me/accounts?fields=id,name,access_token,tasks&limit=100&access_token=${encodeURIComponent(userToken)}`;
      const incomingPages = await fetchAllPages(pageUrl);
      let added = 0;
      for (const incoming of incomingPages) {
        const existing = state.pages.find((p) => p.pageId === String(incoming.id));
        const record = { id: existing?.id || id('page'), name: incoming.name || `Page ${incoming.id}`, pageId: String(incoming.id), groupId: existing?.groupId || '', token: incoming.access_token || existing?.token || '', tasks: incoming.tasks || existing?.tasks || [] };
        if (existing) Object.assign(existing, record); else { state.pages.push(record); added += 1; }
      }
      await saveState();
      return res.writeHead(302, { Location: `/?oauth=success&count=${incomingPages.length}&added=${added}` }).end();
    } catch (error) { return oauthError(res, error.message); }
  }
  return false;
}

async function handleMediaUpload(req, res) {
  const raw = await body(req);
  const type = req.headers['content-type'] || '';
  const match = type.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!match) return send(res, 400, { error: 'multipart boundary missing' });
  const boundary = Buffer.from(`--${match[1] || match[2]}`);
  const start = raw.indexOf(boundary);
  const headerEnd = raw.indexOf(Buffer.from('\r\n\r\n'), start);
  const end = raw.indexOf(boundary, headerEnd + 4);
  if (start < 0 || headerEnd < 0 || end < 0) return send(res, 400, { error: 'invalid multipart upload' });
  const headers = raw.subarray(start, headerEnd).toString('utf8');
  const fileMatch = headers.match(/filename="([^"]*)"/i);
  const fileContentType = (headers.match(/\r\nContent-Type:\s*([^\r\n]+)/i)?.[1] || '').trim().toLowerCase();
  const name = safeName(fileMatch?.[1] || 'upload.bin');
  const file = raw.subarray(headerEnd + 4, end - 2);
  const storedName = `${Date.now()}-${crypto.randomUUID()}-${name}`;
  await fsp.writeFile(path.join(mediaDir, storedName), file);
  const mediaType = req.headers['x-media-type'] || 'video';
  if (mediaType === 'video' && fileContentType && !fileContentType.startsWith('video/')) { await fsp.rm(path.join(mediaDir, storedName), { force: true }); return send(res, 400, { error: 'Bạn chọn loại Video nhưng file không phải video.' }); }
  if (mediaType === 'image' && fileContentType && !fileContentType.startsWith('image/')) { await fsp.rm(path.join(mediaDir, storedName), { force: true }); return send(res, 400, { error: 'Bạn chọn loại Hình ảnh nhưng file không phải ảnh.' }); }
  return send(res, 201, { name: storedName, originalName: name, size: file.length, mediaType });
}

async function publishContent(content) {
  const targets = state.pages.filter((p) => content.groupIds?.includes(p.groupId) || content.pageIds?.includes(p.id));
  const results = [];
  for (const page of targets) {
    if (!pageForPublish(page)) {
      results.push({ pageId: page.id, pageName: page.name, status: 'skipped', message: 'Chưa có Page ID hoặc Page Access Token' });
      continue;
    }
    try {
      const endpoint = content.mediaType === 'video' ? 'videos' : content.mediaType === 'image' ? 'photos' : 'feed';
      const url = `https://graph.facebook.com/${graphVersion}/${page.pageId}/${endpoint}`;
      const form = new FormData();
      form.append('access_token', page.token);
      if (content.caption) form.append(content.mediaType === 'text' ? 'message' : 'description', content.caption);
      if (content.mediaName && content.mediaType !== 'text') {
        const fileBuffer = await fsp.readFile(path.join(mediaDir, content.mediaName));
        form.append(content.mediaType === 'video' ? 'source' : 'source', new Blob([fileBuffer]), content.mediaName);
      }
      const response = await fetch(url, { method: 'POST', body: form });
      const payload = await response.json().catch(() => ({}));
    results.push({ pageId: page.id, pageName: page.name, status: response.ok ? 'published' : 'failed', message: response.ok ? 'Đã đăng thành công' : (payload.error?.error_user_msg || payload.error?.message || `Meta API HTTP ${response.status}`), response: payload });
    } catch (error) {
      results.push({ pageId: page.id, pageName: page.name, status: 'failed', message: error.message });
    }
  }
  state.logs.unshift({ id: id('log'), contentId: content.id, createdAt: new Date().toISOString(), results });
  content.lastRunAt = new Date().toISOString();
  content.status = results.some((r) => r.status === 'published') ? 'published' : 'failed';
  await saveState();
  return results;
}

async function api(req, res, url) {
  const metaHandled = await pageMetaApi(req, res, url);
  if (metaHandled) return metaHandled;
  if (req.method === 'GET' && url.pathname === '/api/state') return send(res, 200, publicState());
  if (req.method === 'POST' && url.pathname === '/api/media') return handleMediaUpload(req, res);
  if (req.method === 'POST' && url.pathname === '/api/groups') {
    const input = await jsonBody(req);
    const group = { id: id('group'), name: String(input.name || 'Nhóm mới').trim(), color: input.color || '#7c5cff' };
    if (state.groups.some((g) => g.name.toLowerCase() === group.name.toLowerCase())) return send(res, 409, { error: 'Tên nhóm đã tồn tại' });
    state.groups.push(group); await saveState(); return send(res, 201, group);
  }
  if (req.method === 'POST' && url.pathname === '/api/pages') {
    const input = await jsonBody(req);
    const page = { id: id('page'), name: String(input.name || 'Page chưa đặt tên').trim(), pageId: String(input.pageId || '').trim(), groupId: input.groupId || '', token: String(input.token || '').trim(), tasks: [] };
    state.pages.push(page); await saveState(); return send(res, 201, { ...page, token: page.token ? '••••••••' : '' });
  }
  if (req.method === 'POST' && url.pathname === '/api/pages/import') {
    const input = await jsonBody(req);
    const pages = Array.isArray(input.pages) ? input.pages : [];
    const added = pages.filter((p) => p.name).map((p) => ({ id: id('page'), name: String(p.name).trim(), pageId: String(p.pageId || '').trim(), groupId: p.groupId || '', token: String(p.token || '').trim(), tasks: Array.isArray(p.tasks) ? p.tasks : [] }));
    state.pages.push(...added); await saveState(); return send(res, 201, { count: added.length });
  }
  if (req.method === 'DELETE' && url.pathname.startsWith('/api/pages/')) {
    const pageId = url.pathname.split('/').pop(); state.pages = state.pages.filter((p) => p.id !== pageId); await saveState(); return send(res, 200, { ok: true });
  }
  if (req.method === 'PATCH' && url.pathname.startsWith('/api/pages/') && url.pathname !== '/api/pages/bulk-group') {
    const pageId = url.pathname.split('/').pop(); const page = state.pages.find((p) => p.id === pageId);
    if (!page) return send(res, 404, { error: 'page not found' });
    const input = await jsonBody(req); page.groupId = String(input.groupId || ''); await saveState(); return send(res, 200, { ok: true });
  }
  if (req.method === 'PATCH' && url.pathname === '/api/pages/bulk-group') {
    const input = await jsonBody(req);
    const pageIds = new Set(Array.isArray(input.pageIds) ? input.pageIds.map(String) : []);
    const groupId = String(input.groupId || '');
    let updated = 0;
    state.pages.forEach((page) => { if (pageIds.has(page.id)) { page.groupId = groupId; updated += 1; } });
    await saveState();
    return send(res, 200, { ok: true, updated });
  }
  if (req.method === 'DELETE' && url.pathname.startsWith('/api/groups/')) {
    const groupId = url.pathname.split('/').pop();
    state.groups = state.groups.filter((g) => g.id !== groupId);
    state.pages.forEach((p) => { if (p.groupId === groupId) p.groupId = ''; });
    state.contents.forEach((c) => { c.groupIds = (c.groupIds || []).filter((id) => id !== groupId); });
    await saveState(); return send(res, 200, { ok: true });
  }
  if (req.method === 'POST' && url.pathname === '/api/content') {
    const input = await jsonBody(req);
    const content = { id: id('content'), title: String(input.title || 'Nội dung chưa đặt tên').trim(), caption: String(input.caption || ''), mediaName: input.mediaName || '', mediaType: input.mediaType || 'video', groupIds: Array.isArray(input.groupIds) ? input.groupIds : [], pageIds: Array.isArray(input.pageIds) ? input.pageIds : [], scheduledAt: input.scheduledAt || '', status: input.scheduledAt ? 'scheduled' : 'draft', createdAt: new Date().toISOString() };
    state.contents.unshift(content); await saveState(); return send(res, 201, content);
  }
  if ((req.method === 'PATCH' || req.method === 'DELETE') && url.pathname.startsWith('/api/content/')) {
    const contentId = url.pathname.split('/').pop();
    const content = state.contents.find((c) => c.id === contentId);
    if (!content) return send(res, 404, { error: 'content not found' });
    if (req.method === 'DELETE') {
      const mediaName = content.mediaName;
      state.contents = state.contents.filter((c) => c.id !== contentId);
      state.logs = state.logs.filter((log) => log.contentId !== contentId);
      if (mediaName && !state.contents.some((c) => c.mediaName === mediaName)) await fsp.rm(path.join(mediaDir, mediaName), { force: true });
      await saveState();
      return send(res, 200, { ok: true });
    }
    const input = await jsonBody(req);
    if (input.title !== undefined) content.title = String(input.title).trim();
    if (input.caption !== undefined) content.caption = String(input.caption);
    if (Array.isArray(input.groupIds)) content.groupIds = input.groupIds;
    if (Array.isArray(input.pageIds)) content.pageIds = input.pageIds;
    if (input.scheduledAt !== undefined) {
      content.scheduledAt = String(input.scheduledAt || '');
      content.status = content.scheduledAt ? 'scheduled' : 'draft';
    }
    await saveState();
    return send(res, 200, content);
  }
  if (req.method === 'POST' && url.pathname.startsWith('/api/publish/')) {
    const contentId = url.pathname.split('/').pop(); const content = state.contents.find((c) => c.id === contentId);
    if (!content) return send(res, 404, { error: 'content not found' });
    const results = await publishContent(content); return send(res, 200, { results });
  }
  return send(res, 404, { error: 'not found' });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith('/auth/meta')) return await metaAuth(req, res, url);
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    const requested = url.pathname === '/' ? '/index.html' : url.pathname;
    let filePath = path.normalize(path.join(publicDir, requested));
    if (!filePath.startsWith(publicDir)) return send(res, 403, { error: 'forbidden' });
    if (!fs.existsSync(filePath) && !path.extname(url.pathname)) filePath = path.join(publicDir, 'index.html');
    if (!fs.existsSync(filePath)) return send(res, 404, { error: 'not found' });
    const ext = path.extname(filePath);
    const type = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json' }[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': `${type}; charset=utf-8` });
    fs.createReadStream(filePath).pipe(res);
  } catch (error) { send(res, 500, { error: error.message }); }
});

server.listen(port, '127.0.0.1', () => console.log(`PageOps Local: http://127.0.0.1:${port}`));

// Local scheduler: the app must remain running for scheduled publishing.
setInterval(async () => {
  const now = Date.now();
  for (const content of state.contents) {
    if (content.status === 'scheduled' && content.scheduledAt && Date.parse(content.scheduledAt) <= now) {
      await publishContent(content);
    }
  }
}, 30_000);
